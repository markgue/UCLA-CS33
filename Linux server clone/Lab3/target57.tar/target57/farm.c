/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_326(unsigned *p)
{
    *p = 3347695641U;
}

unsigned getval_184()
{
    return 3347662883U;
}

void setval_242(unsigned *p)
{
    *p = 1481678658U;
}

unsigned addval_458(unsigned x)
{
    return x + 3264254040U;
}

void setval_205(unsigned *p)
{
    *p = 2428995912U;
}

void setval_438(unsigned *p)
{
    *p = 3344465704U;
}

unsigned getval_106()
{
    return 2462550344U;
}

unsigned getval_296()
{
    return 3281031256U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_354(unsigned *p)
{
    *p = 3229931147U;
}

unsigned addval_376(unsigned x)
{
    return x + 3286280520U;
}

void setval_318(unsigned *p)
{
    *p = 1623381641U;
}

unsigned getval_487()
{
    return 3286273352U;
}

unsigned getval_474()
{
    return 3247489417U;
}

unsigned addval_110(unsigned x)
{
    return x + 3523267209U;
}

void setval_251(unsigned *p)
{
    *p = 3767093495U;
}

unsigned getval_161()
{
    return 2430634824U;
}

unsigned addval_253(unsigned x)
{
    return x + 3677929737U;
}

void setval_134(unsigned *p)
{
    *p = 3380134281U;
}

void setval_114(unsigned *p)
{
    *p = 3380920713U;
}

unsigned getval_173()
{
    return 3223374473U;
}

void setval_241(unsigned *p)
{
    *p = 2425411209U;
}

unsigned addval_456(unsigned x)
{
    return x + 3229928105U;
}

void setval_327(unsigned *p)
{
    *p = 3682124169U;
}

unsigned getval_123()
{
    return 3285621229U;
}

unsigned getval_426()
{
    return 3285614885U;
}

unsigned addval_246(unsigned x)
{
    return x + 3525362056U;
}

unsigned getval_396()
{
    return 3281046157U;
}

void setval_427(unsigned *p)
{
    *p = 3229931017U;
}

unsigned getval_393()
{
    return 3229927945U;
}

void setval_258(unsigned *p)
{
    *p = 3284249063U;
}

void setval_380(unsigned *p)
{
    *p = 2464188744U;
}

void setval_370(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_147(unsigned x)
{
    return x + 3397989446U;
}

void setval_160(unsigned *p)
{
    *p = 2093203849U;
}

void setval_388(unsigned *p)
{
    *p = 3223377545U;
}

unsigned getval_230()
{
    return 3223374472U;
}

unsigned getval_252()
{
    return 2430634312U;
}

unsigned addval_220(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_493()
{
    return 2429946129U;
}

unsigned addval_464(unsigned x)
{
    return x + 3525364393U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
